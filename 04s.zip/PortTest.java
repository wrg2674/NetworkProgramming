import java.net.ServerSocket;

public class PortTest {

	public static void main(String[] args) {
		System.out.println("포트 스캔 시작");

		ServerSocket ss = null;
		for (int i = 0; i < 65535; i++) {
			/* */
		}

		System.out.println("포트 스캔 끝");
	}

}
