import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class IntClient {
	private String serverAddress;
	private int serverPort;

	private OutputStream out;

	public IntClient(String serverAddress, int serverPort) {
		this.serverAddress = serverAddress;
		this.serverPort = serverPort;

		connectToServer();
	}

	private void connectToServer() {
			Socket socket = /* 소켓 생성 */;
			out = /* 소켓으로부터 출력 스트림 생성 */;
	}

	private void sendMessage(int msg) {
			/* 소켓 스트림에 msg 보내기 */;

			if (msg == 0) {
				/* 소켓 닫기 */

				System.exit(0);
			}

			System.out.println("나: " + msg);
	}

	public void start() {
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.print("데이터를 입력하세요 (종료: '0'): ");
			int message = scanner.nextInt();

			sendMessage(message);
		}
	}

	public static void main(String[] args) {
		String serverAddress = "localhost";
		int serverPort = 54321;

		IntClient client = new IntClient(serverAddress, serverPort);
		client.start();
	}
}
