/**
 * 
 */
/**
 * 
 */
module Week3 {
	requires java.desktop;
}