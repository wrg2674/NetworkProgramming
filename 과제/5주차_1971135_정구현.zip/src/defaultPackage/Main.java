package defaultPackage;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new HWIntFrameClient();
		//new HWIntFrameServer();
		//new HWBufferFrameClient();
		//new HWBufferFrameServer();
		//new HWStringFrameClient();
		//new HWStringFrameServer();
		//new HWPrintWriterFrameClient();
		//new HWPrintWriterFrameServer();
		new HWObjectFrameClient();
		new HWObjectFrameServer();
	}

}
